/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.duarteduarte.li3.processing;

import java.util.List;
import java.util.Map;
import org.duarteduarte.li3.data.Artigo;
import org.duarteduarte.li3.data.Autor;
import org.duarteduarte.li3.data.ArtigosAno;
import org.duarteduarte.li3.data.RedeAutores;
import org.duarteduarte.li3.util.Factories;

/**
 *
 * @author duarteduarte
 */
public class Storage {

    private RedeAutores redeAutores = new RedeAutores();

    public RedeAutores getRedeAutores() {
        return redeAutores;
    }

    public void setAutoresMap(RedeAutores ra) {
        this.redeAutores = ra;
    }

    public ArtigosAno getArtigosAno(int ano) {
        return redeAutores.getArtigosAno(ano);
    }

    public boolean addArtigo(int ano, Artigo artigo) {
        boolean res = false;
        ArtigosAno aux = redeAutores.getArtigosAno(ano);
        if (aux == null) {
            aux = new ArtigosAno();
        }
        res = aux.insereArtigo(artigo);
        redeAutores.insertArtigosAno(ano, aux);

        return res;
    }
    
    public void setFileName(String fileName){
        this.redeAutores.setNomeFicheiro(fileName);
    }

    public void testAutores() {
        Artigo tmp = null, tmp2=null;

        tmp = new Artigo();
        tmp.insereAutor(new Autor("nelson"));
        tmp.insereAutor(new Autor("ze"));

        this.addArtigo(2001, tmp);

        tmp2 = new Artigo();
        tmp2.insereAutor(new Autor("igor"));
        tmp2.insereAutor(new Autor("cardozo"));

        this.addArtigo(2013, tmp2);
    }
}
