/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.duarteduarte.li3.processing;

import java.util.List;
import java.util.Set;
import org.duarteduarte.li3.data.Artigo;
import org.duarteduarte.li3.data.ArtigosAno;
import org.duarteduarte.li3.data.Autor;
import org.duarteduarte.li3.data.RedeAutores;
import org.duarteduarte.li3.util.Factories;

/**
 *
 * @author duarteduarte
 */
public class Statistics {

// grupo1
    // pergunta 1.1
    public String pergunta11(RedeAutores ra) {
        int numeroArtigosLidos = numeroArtigosLidos(ra);
        String nomeFicheiro = ra.getNomeFicheiro();
        String totalNomes = totalNomes(ra);
        int anoMax = ra.getAnoMaximo();
        int anoMin = ra.getAnoMinimo();


        return ("No " + nomeFicheiro + " foram lidos " + numeroArtigosLidos + " artigos, num total de " + totalNomes + "e o intervalo fechado de [" + anoMin + "," + anoMax + "]");
    }

    public int numeroArtigosLidos(RedeAutores rede) {
        int res = 0;

        if (rede == null) {
            throw new IllegalArgumentException("A rede não pode ser vazia.");
        }

        for (ArtigosAno r : rede.getArtigos().values()) {
            res += r.getNumeroArtigos();
        }
        return res;
    }

    public String totalNomes(RedeAutores rede) {
        List<Autor> autores = Factories.giveMeList();
        Set<Autor> autoresDistintos = Factories.giveMeSet();

        if (rede == null) {
            throw new IllegalArgumentException("A rede não pode ser vazia.");
        }
        for (ArtigosAno aa : rede.getArtigos().values()) {
            for (Artigo art : aa.getArtigosAno()) {
                autores.addAll(art.getAutores());
            }
        }

        autoresDistintos.addAll(autores);
        return "" + autores.size() + " nomes, destes " + autoresDistintos.size() + " sao distintos, ";
    }
    // pergunta 1.2
/*
    public String pergunta12(RedeAutores ra) {
        //  número total de autores, número total de artigos de um 
        //único autor, número total de autores que apenas publicaram a solo (sem coautores) e número total de
        //autores que nunca publicaram a solo;

        int numeroTotalAutores = 0;
        int numeroTotalArtigosUnicoAutor = 0;
        int numeroTotalAutoresSolo = 0;
        int numeroTotalAutoresSemSolo = 0;

        if (ra == null) {
            throw new IllegalArgumentException("A rede não pode ser vazia.");
        }

        for (ArtigosAno r : ra.getArtigos().values()) {
            for (List<Artigo> art : r.getArtigosAno()) {
                if (r.getArtigosAno().size() == 1) {
                    numeroTotalArtigosUnicoAutor++;
                }
            }
        }



        return "";

    }*/
// grupo 2
    //pergunta 2.1
    //pergunta 2.1 a)
}
