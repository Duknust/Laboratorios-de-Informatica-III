package org.duarteduarte.li3.data;

import java.util.List;
import org.duarteduarte.li3.data.Artigo;
import org.duarteduarte.li3.util.Factories;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author duarteduarte
 */
public class ArtigosAno {

    private List<Artigo> artigosAno = null;
    private int numeroArtigos = 0;
    private int totalAutores = 0;

    public ArtigosAno() {
        this.artigosAno = Factories.giveMeList();
    }

    public ArtigosAno(ArtigosAno aa) {
        this.artigosAno = Factories.giveMeList();
        this.artigosAno.addAll(aa.getArtigosAno());
        this.numeroArtigos = aa.getNumeroArtigos();
        this.totalAutores = aa.getTotalAutores();
    }

    public int getNumeroArtigos() {
        return numeroArtigos;
    }

    public void setNumeroArtigos(int numeroArtigos) {
        this.numeroArtigos = numeroArtigos;
    }

    public int getTotalAutores() {
        return totalAutores;
    }

    public void setTotalAutores(int totalAutores) {
        this.totalAutores = totalAutores;
    }

    @Override
    public String toString() {
        return "RedeAutores{" + "redeAutores=" + artigosAno + '}';
    }

    public boolean insereArtigo(Artigo artigo) {
        boolean res = false;
        if (res = this.artigosAno.add(artigo)) {
            this.numeroArtigos++;
            this.totalAutores += artigo.getNumeroAutores();
        }
        return res;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 61 * hash + (this.artigosAno != null ? this.artigosAno.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ArtigosAno other = (ArtigosAno) obj;
        if (this.artigosAno != other.artigosAno && (this.artigosAno == null || !this.artigosAno.equals(other.artigosAno))) {
            return false;
        }
        return true;
    }

    public List<Artigo> getArtigosAno() {
        return artigosAno;
    }

    public void setArtigosAno(List<Artigo> artigosAno) {
        this.artigosAno = artigosAno;
    }

    @Override
    public Object clone() {
        return new ArtigosAno(this);
    }
}
