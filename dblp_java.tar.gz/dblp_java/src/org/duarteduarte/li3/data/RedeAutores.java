/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.duarteduarte.li3.data;

import java.io.Serializable;
import java.util.Map;
import org.duarteduarte.li3.util.Factories;

/**
 *
 * @author duarteduarte
 */
public class RedeAutores implements Serializable {

    private String nomeFicheiro;
    private int anoMinimo;
    private int anoMaximo;
    private Map<Integer, ArtigosAno> artigos;

    public RedeAutores() {
        this.nomeFicheiro = "";
        this.anoMinimo = Integer.MAX_VALUE;
        this.anoMaximo = Integer.MIN_VALUE;
        this.artigos = Factories.giveMeMap();
    }

    protected RedeAutores(String nomeFicheiro, int anoMin, int anoMax, Map<Integer, ArtigosAno> art) {
        this.nomeFicheiro = nomeFicheiro;
        this.anoMinimo = anoMin;
        this.anoMaximo = anoMax;
        this.artigos = Factories.giveMeMap();
        this.artigos.putAll(art);
    }

    protected RedeAutores(RedeAutores ra) {
        this.nomeFicheiro = ra.getNomeFicheiro();
        this.anoMinimo = ra.getAnoMinimo();
        this.anoMaximo = ra.getAnoMaximo();
        this.artigos = Factories.giveMeMap();
        this.artigos.putAll(ra.getArtigos());
    }

    public String getNomeFicheiro() {
        return nomeFicheiro;
    }

    public void setNomeFicheiro(String nomeFicheiro) {
        this.nomeFicheiro = nomeFicheiro;
    }

    public int getAnoMinimo() {
        return this.anoMinimo;
    }

    public void setAnoMinimo(int anoMinimo) {
        this.anoMinimo = anoMinimo;
    }

    public int getAnoMaximo() {
        return this.anoMaximo;
    }

    public void setAnoMaximo(int anoMaximo) {
        this.anoMaximo = anoMaximo;
    }

    public ArtigosAno getArtigosAno(int ano) {
        ArtigosAno res = this.artigos.get(ano);

        return (ArtigosAno) (res != null ? res.clone() : null);
    }

    public boolean insertArtigosAno(int ano, ArtigosAno artigos) {
        boolean res = false;
        if (res = (this.artigos.put(ano, artigos) != null)) {
            this.anoMinimo = (ano < this.anoMinimo) ? ano : this.anoMinimo;
            this.anoMaximo = (ano > this.anoMaximo) ? ano : this.anoMaximo;
        }

        return res;
    }

    public Map<Integer, ArtigosAno> getArtigos() {
        return this.artigos;
    }

    @Override
    public Object clone() {
        return new RedeAutores(this);
    }

    @Override
    public String toString() {
        return "RedeAutores{" + "nomeFicheiro=" + nomeFicheiro + ", anoMinimo=" + anoMinimo + ", anoMaximo=" + anoMaximo + ", artigos=" + artigos + '}';
    }
}
